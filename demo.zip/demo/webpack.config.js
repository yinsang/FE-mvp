module.exports = {
  module: {
    rules: [
      {
        test: /.jsx?$/,
        use: {
          loader: 'babel-loader'
        }
      }
    ]
  }
}
